﻿namespace PriceQuotationApp2
{
    public class PriceQuotationModel
    {
        public decimal Subtotal { get; set; }
        public decimal DiscountPercent { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal Total { get; set; }

        public void Calculate()
        {
            DiscountAmount = Subtotal * (DiscountPercent / 100);
            Total = Subtotal - DiscountAmount;
        }
    }
}
