﻿using Microsoft.AspNetCore.Mvc;

namespace PriceQuotationApp2
{
    public class PriceQuotationController : Controller
    {
        public IActionResult Index()
        {
            var model = new PriceQuotationModel();
            return View(model);
        }

        [HttpPost]
        public IActionResult Index(PriceQuotationModel model)
        {
            if (ModelState.IsValid)
            {
                model.Calculate();
            }

            return View(model);
        }

        public IActionResult Clear()
        {
            var model = new PriceQuotationModel();
            return View("Index", model);
        }
    }
}
